"""
Este script está diseñado para modelar una curva vial y simular el flujo de agua, considerando la inclinación transversal y la pendiente longitudinal. Permite calcular la ubicación óptima de drenajes para evitar acumulaciones de agua, especialmente en el centro de la curva donde suele concentrarse el flujo.

## Funcionamiento:
1. **Ingreso de datos:** El usuario proporciona información como la distancia total de la curva, el radio de curvatura, la inclinación transversal, la pendiente longitudinal y la dirección de la curva.
2. **Generación de curva:** El programa calcula los puntos que conforman la curva.
3. **Ubicación de drenajes:** Basándose en la inclinación transversal y pendiente, los drenajes se colocan en los puntos más bajos del tercio central de la curva.
4. **Visualización:** Se genera un gráfico que muestra la curva, los drenajes y el flujo de agua simulado.
5. **Información adicional:** Imprime un resumen detallado de los datos ingresados y los puntos de drenaje calculados.

## Ejemplo de uso:
Ingrese los siguientes valores cuando se le solicite:
- Distancia total de la curva: 150 metros
- Radio de curvatura: 50 metros
- Inclinación transversal: 5 grados
- Pendiente longitudinal: 2 %
- Dirección de la curva: derecha
- Número de drenajes: 3

En este caso, los drenajes se colocarán hacia el centro geométrico de la curva, donde el flujo de agua converge debido a la inclinación transversal.

Los resultados incluyen:
- Un gráfico con la curva, los drenajes (marcados en rojo) y la simulación del flujo de agua.
- Coordenadas precisas de los drenajes.

"""
import numpy as np
import matplotlib.pyplot as plt
import geojson
from math import radians, tan, sin, cos, pi

def solicitar_float(mensaje):
    while True:
        try:
            return float(input(mensaje))
        except ValueError:
            print("Por favor, ingrese un número válido.")

def solicitar_direccion(mensaje):
    while True:
        direccion = input(mensaje).strip().lower()
        if direccion in ["izquierda", "derecha"]:
            return direccion
        else:
            print("Por favor, ingrese 'izquierda' o 'derecha'.")

# Paso 1: Lectura proporcionada del usuario
distancia_total = solicitar_float("Ingrese la distancia total de la curva en metros: ")
radio_curvatura = solicitar_float("Ingrese el radio de curvatura en metros: ")
inclinacion_transversal = solicitar_float("Ingrese el ángulo de inclinación transversal en grados: ")
pendiente_longitudinal = solicitar_float("Ingrese la pendiente longitudinal en porcentaje: ")
direccion_curva = solicitar_direccion("Ingrese la dirección de la curva (izquierda/derecha): ")
num_drenajes = int(input("Ingrese el número de drenajes que desea colocar (use su criterio basado en el nivel de acumulación de agua): "))

# Paso 2: Puntos de la curva
def generar_curva(radio, distancia, direccion, inclinacion_trans, pendiente, num_puntos=100):
    angulo_total = (distancia / (2 * pi * radio)) * 360  # Convertir la distancia a ángulo en grados
    angulos = np.linspace(0, radians(angulo_total), num_puntos)
    puntos = []
    for angulo in angulos:
        x = radio * sin(angulo)
        y = radio * (1 - cos(angulo))
        y += pendiente / 100 * x  # Ajustar por pendiente longitudinal
        if direccion == "izquierda":
            x = -x  # Invertir la dirección
        puntos.append([x, y])
    return puntos

coordenadas = generar_curva(radio_curvatura, distancia_total, direccion_curva, inclinacion_transversal, pendiente_longitudinal)

curva_geojson = geojson.LineString(coordenadas)
with open('curva.geojson', 'w') as f:
    geojson.dump(curva_geojson, f)

# Paso 3: Colocar drenajes de la curva basado en flujo del agua

def colocar_drenajes_centro(coordenadas, inclinacion_trans, pendiente_long, num_drenajes):
    # Identificar el tercio central de la curva
    tercio_inicio = len(coordenadas) // 3
    tercio_final = 2 * len(coordenadas) // 3
    coordenadas_centrales = coordenadas[tercio_inicio:tercio_final]

    # Calcular flujo hacia el centro combinando inclinación transversal y pendiente longitudinal
    flujo = [
        (punto[0], punto[1], abs(tan(radians(inclinacion_trans)) * punto[0] + pendiente_long / 100 * punto[0] - punto[1]))
        for punto in coordenadas_centrales
    ]
    # Ordenar por cercanía al flujo central
    flujo_ordenado = sorted(flujo, key=lambda punto: punto[2])
    # Seleccionar los puntos para los drenajes
    puntos_drenaje = [[p[0], p[1]] for p in flujo_ordenado[:num_drenajes]]
    return puntos_drenaje

puntos_drenaje = colocar_drenajes_centro(coordenadas, inclinacion_transversal, pendiente_longitudinal, num_drenajes)

# Paso 4: Visualizar curva con matplotlib
x, y = zip(*coordenadas)
drenaje_x, drenaje_y = zip(*puntos_drenaje)

# Simulacion del flujo del agua 
def simular_flujo(x, y, inclinacion_trans, num_lineas=10):
    for i in range(num_lineas):
        flujo_x = [xi for xi in x]
        flujo_y = [yi - (i * 0.1) for yi in y]  # Simular descenso en flujo
        plt.plot(flujo_x, flujo_y, linestyle='--', alpha=0.5, color='cyan', label='Flujo de agua' if i == 0 else "")

plt.figure(figsize=(12, 8))
plt.plot(x, y, label='Curva diseñada', color='b', linewidth=2)
plt.scatter(drenaje_x, drenaje_y, color='r', marker='o', s=100, label='Puntos de Drenaje')
simular_flujo(x, y, inclinacion_transversal)

# Informacion añadida al grafico con la libreria matplotlib
info_text = (
    f"Distancia total: {distancia_total:.2f} m\n"
    f"Radio de curvatura: {radio_curvatura:.2f} m\n"
    f"Pendiente longitudinal: {pendiente_longitudinal:.2f}%\n"
    f"Inclinación transversal: {inclinacion_transversal:.2f}°\n"
    f"Dirección: {direccion_curva.capitalize()}\n"
    f"Número de drenajes: {num_drenajes}"
)
plt.gcf().text(0.15, 0.85, info_text, fontsize=10, bbox=dict(facecolor='white', alpha=0.8))

plt.xlabel('Distancia horizontal (m)')
plt.ylabel('Distancia vertical (m)')
plt.title(f'Diseño de Curva con Drenajes\nRadio: {radio_curvatura:.2f} m, Pendiente: {pendiente_longitudinal:.2f}%')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.7)
plt.axhline(0, color='black', linewidth=0.5)
plt.axvline(0, color='black', linewidth=0.5)
plt.show()

# Paso 5: Información adicional de la curva
longitud_curva = distancia_total
print(f"\n=== Información de la Curva ===")
print(f"Dirección de la curva: {direccion_curva.capitalize()}")
print(f"Longitud total de la curva: {longitud_curva:.2f} metros")
print(f"Radio de curvatura: {radio_curvatura:.2f} metros")
print(f"Pendiente longitudinal: {pendiente_longitudinal:.2f}%")
print(f"Número de drenajes ingresados: {num_drenajes} (Colocados hacia el centro de la curva considerando el flujo)")
print(f"Puntos de drenaje (coordenadas): {puntos_drenaje}")
1